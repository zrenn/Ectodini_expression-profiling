##### Author: Albyn Jones
##### Date : 2009summer
##### These R comands will calculate exact rather than approximat p-values
##### This is important only for genes for which there is missing data
##### While controversial, the Renn lab manually filters bad spots
##### HENCE we should use this script
##### There are three function
############Contrasts.fit
	### this replaces contrasts.fit
############LS.series
	### this replaces something called internally (you don't need to use it)
########### EBayes
	### this replaces ebayes and eBayes
################################################################################
#
# LOAD THE FOLLOWING FUNCTIONS
#
##################################################################################
Contrasts.fit <-
function (object, design = NULL, ndups = 1, spacing = 1, block = NULL, 
     weights = NULL,contrasts=NULL, ...) 
{
    y <- getEAWP(object)
    if (is.null(design)) 
        if (is.null(y$design)) 
            design <- matrix(1, ncol(y$exprs), 1)
        else design <- as.matrix(object$design)
    else design <- as.matrix(design)
    if (mode(design) != "numeric") 
        stop("design must be a numeric matrix")
    ne <- nonEstimable(design)
    if (!is.null(ne)) 
        cat("Coefficients not estimable:", paste(ne, collapse = " "), 
            "\n")
    if (missing(ndups) && !is.null(y$printer$ndups)) 
        ndups <- y$printer$ndups
    if (missing(spacing) && !is.null(y$printer$spacing)) 
        spacing <- y$printer$spacing
    if (missing(weights) && !is.null(y$weights)) 
        weights <- y$weights
    if (ndups > 1) {
        if (!is.null(y$probes)) 
            y$probes <- uniquegenelist(y$probes, ndups = ndups, 
                spacing = spacing)
        if (!is.null(y$Amean)) 
            y$Amean <- rowMeans(unwrapdups(as.matrix(y$Amean), 
                ndups = ndups, spacing = spacing), na.rm = TRUE)
    }
    fit <- LS.series(y$exprs, design = design, ndups = ndups, 
            spacing = spacing, weights = weights,contrasts=contrasts)
        if (NCOL(fit$coef) > 1) {
        i <- is.na(fit$coef)
        i <- apply(i[, 1] == i[, -1, drop = FALSE], 1, all)
        n <- sum(!i)
        if (n > 0) 
            warning("Partial NA coefficients for ", n, " probe(s)", 
                call. = FALSE)
    }
    fit$genes <- y$probes
    fit$Amean <- y$Amean
    fit$method <- "ls"
    fit$design <- design
    new("MArrayLM", fit)
}

LS.series <-
function (M, design = NULL, ndups = 1, spacing = 1, weights = NULL,
          contrasts=NULL) 
{
    M <- as.matrix(M)
    narrays <- ncol(M)
    if (is.null(design)) 
        design <- matrix(1, narrays, 1)
    design <- as.matrix(design)
    nbeta <- ncol(design)
    CONTR <- !is.null(contrasts)
    if(!CONTR) warning("no contrasts specified: will return lmFit")
    else {
      contrasts <- as.matrix(contrasts)
      rn <- rownames(contrasts)
      cn <- colnames(design)
      ncontr = ncol(contrasts)
      ncoef <- nbeta
      if (!is.null(rn) && !is.null(cn) && any(rn != cn)) 
        warning("row names of contrasts don't match col names of coefficients")
      if (NROW(contrasts) != ncoef) 
        stop("Number of rows of contrast matrix must match number of coefficients")

    }
    coef.names <- colnames(design)
    if (!is.null(weights)) {
        weights <- asMatrixWeights(weights, dim(M))
        weights[weights <= 0] <- NA
        M[!is.finite(weights)] <- NA
    }
    if (ndups > 1) {
        M <- unwrapdups(M, ndups = ndups, spacing = spacing)
        design <- design %x% rep(1, ndups)
        if (!is.null(weights)) 
            weights <- unwrapdups(weights, ndups = ndups, spacing = spacing)
    }
    ngenes <- nrow(M)
    stdev.unscaled <- beta <- matrix(NA, ngenes, nbeta, 
                   dimnames = list(rownames(M), coef.names))
    sigma <- rep(NA, ngenes)
    df.residual <- rep(0, ngenes)
    NoProbeWts <- !any(is.na(M)) && (is.null(weights) || !is.null(attr(weights, 
        "arrayweights")))
    if (NoProbeWts) {
        if(CONTR) warning("No missing data: use contrasts.fit")
        if (is.null(weights)) 
            fit <- lm.fit(design, t(M))
        else {
            fit <- lm.wfit(design, t(M), weights[1, ])
            fit$weights <- NULL
        }
        if (fit$df.residual > 0) 
            fit$sigma <- sqrt(colMeans(fit$effects[(fit$rank + 
                1):narrays, , drop = FALSE]^2))
        else fit$sigma <- rep(NA, ngenes)
        fit$fitted.values <- fit$residuals <- fit$effects <- NULL
        fit$coefficients <- t(fit$coefficients)
        fit$cov.coefficients <- chol2inv(fit$qr$qr, size = fit$qr$rank)
        est <- fit$qr$pivot[1:fit$qr$rank]
        dimnames(fit$cov.coefficients) <- list(coef.names[est], 
            coef.names[est])
        stdev.unscaled[, est] <- matrix(sqrt(diag(fit$cov.coefficients)), 
            ngenes, fit$qr$rank, byrow = TRUE)
        fit$stdev.unscaled <- stdev.unscaled
        fit$df.residual <- rep.int(fit$df.residual, ngenes)
        dimnames(fit$stdev.unscaled) <- dimnames(fit$stdev.unscaled) <- dimnames(fit$coefficients)
        fit$pivot <- fit$qr$pivot
        return(fit)
    }
    if(CONTR){
      Contrasts=matrix(NA,nrow=ngenes,ncol=ncontr)
      colnames(Contrasts)=colnames(contrasts)
      Contr.stdev.unscaled=matrix(NA,nrow=ngenes,ncol=ncontr)
      colnames(Contr.stdev.unscaled)=colnames(contrasts)
    }
    for (i in 1:ngenes) {
        y <- as.vector(M[i, ])
        obs <- is.finite(y)
        if (sum(obs) > 0) {
            X <- design[obs, , drop = FALSE]
            y <- y[obs]
            if (is.null(weights)) 
                out <- lm.fit(X, y)
            else {
                w <- as.vector(weights[i, obs])
                out <- lm.wfit(X, y, w)
            }
            est <- !is.na(out$coef)
            beta[i, ] <- out$coef
            stdev.unscaled[i, est] <- sqrt(diag(chol2inv(out$qr$qr, 
                size = out$rank)))
            df.residual[i] <- out$df.residual
            if (df.residual[i] > 0) 
                if (is.null(weights)) 
                  sigma[i] <- sqrt(sum(out$residuals^2)/out$df.residual)
                else sigma[i] <- sqrt(sum(w * out$residuals^2)/out$df.residual)
            if(CONTR & all(est)) {
              Contrasts[i,] <- beta[i,] %*% contrasts
              QR <- qr(X)
              COV <- chol2inv(QR$qr)
              Contr.stdev.unscaled[i,] <-
                drop(sqrt(diag(t(contrasts) %*% COV %*% contrasts)))
            }
        }
    }
    QR <- qr(design)
    cov.coef <- chol2inv(QR$qr, size = QR$rank)
    est <- QR$pivot[1:QR$rank]
    dimnames(cov.coef) <- list(coef.names[est], coef.names[est])
    A <- list(coefficients = drop(beta), stdev.unscaled = drop(stdev.unscaled), 
        sigma = sigma, df.residual = df.residual, cov.coefficients = cov.coef, 
        pivot = QR$pivot)
    if(CONTR) {
        A$contrasts <- contrasts
        A$stdev.unscaled <- drop(Contr.stdev.unscaled)
        A$coefficients=drop(Contrasts)
      }
    A
}
EBayes <-
function (fit, proportion = 0.01, stdev.coef.lim = c(0.1, 4)) 
{
    eb <- ebayes(fit = fit, proportion = proportion, stdev.coef.lim = stdev.coef.lim)
    fit$df.prior <- eb$df.prior
    fit$s2.prior <- eb$s2.prior
    fit$var.prior <- eb$var.prior
    fit$proportion <- proportion
    fit$s2.post <- eb$s2.post
    fit$t <- eb$t
    fit$p.value <- eb$p.value
    fit$lods <- eb$lods
    #decideTestsF deleted
    fit
}




##############################################################
########### Heather's resultsSummary function  (tada)
######### 20100525
## resultsSummary function that will produce an object with the summarized results for different P values, for any number of contrasts.

########## Suzy just named it "tada".
#example:  tada(fit.bayes, threshold=c(0.1, "fdr", 0.05, "fdr", .1, "none", .05, "none"), filename="rstest.csv")

tada<-function(fit.bayes,threshold, filename, ...){
if  (file.exists(filename)==TRUE)
  warning("designated filename already exists", domain = NA)
thresh<-matrix(threshold, ncol=2, nrow=length(threshold)/2, byrow=TRUE)
p<-as.numeric(thresh[,1])
am<-thresh[,2]
for(i in 1:length(p)){
label<-matrix(data=c(p[i],am[i]), nrow=1, ncol=2)
colnames(label)<-c("P-value","multiple testing correction")
write.csvHM(label, file=filename, append=T, row.names=FALSE)
rsummary<-summary(decideTests(fit.bayes, method = "separate", adjust.method=am[i], p.value=p[i]))
write.csvHM(rsummary, file=filename, append=T)}
}

write.csvHM<-function (...) 
{
    Call <- match.call(expand.dots = TRUE)
    for (argname in c("col.names", "sep", "dec", "qmethod")) if (!is.null(Call[[argname]])) 
        warning(gettextf("attempt to set '%s' ignored", argname), 
            domain = NA)
    rn <- eval.parent(Call$row.names)
    Call$col.names <- if (is.logical(rn) && !rn) 
        TRUE
    else NA
    Call$sep <- ","
    Call$dec <- "."
    Call$qmethod <- "double"
    Call[[1L]] <- as.name("write.tableHM")
    eval.parent(Call)
}

write.tableHM<-function (x, file = "", append = FALSE, quote = TRUE, sep = " ", 
    eol = "\n", na = "NA", dec = ".", row.names = TRUE, col.names = TRUE, 
    qmethod = c("escape", "double")) 
{
    qmethod <- match.arg(qmethod)
    if (is.logical(quote) && (length(quote) != 1L || is.na(quote))) 
        stop("'quote' must be 'TRUE', 'FALSE' or numeric")
    quoteC <- if (is.logical(quote)) 
        quote
    else TRUE
    qset <- is.logical(quote) && quote
    if (!is.data.frame(x) && !is.matrix(x)) 
        x <- data.frame(x)
    makeRownames <- isTRUE(row.names)
    makeColnames <- is.logical(col.names) && !identical(FALSE, 
        col.names)
    if (is.matrix(x)) {
        p <- ncol(x)
        d <- dimnames(x)
        if (is.null(d)) 
            d <- list(NULL, NULL)
        if (is.null(d[[1L]]) && makeRownames) 
            d[[1L]] <- seq_len(nrow(x))
        if (is.null(d[[2L]]) && makeColnames && p > 0L) 
            d[[2L]] <- paste("V", 1L:p, sep = "")
        if (qset) 
            quote <- if (is.character(x)) 
                seq_len(p)
            else numeric(0L)
    }
    else {
        if (qset) 
            quote <- if (length(x)) 
                which(unlist(lapply(x, function(x) is.character(x) || 
                  is.factor(x))))
            else numeric(0L)
        if (any(sapply(x, function(z) length(dim(z)) == 2 && 
            dim(z)[2L] > 1))) {
            c1 <- names(x)
            x <- as.matrix(x, rownames.force = makeRownames)
            d <- dimnames(x)
            if (qset) {
                ord <- match(c1, d[[2L]], 0L)
                quote <- ord[quote]
                quote <- quote[quote > 0L]
            }
        }
        else d <- list(if (makeRownames) row.names(x), if (makeColnames) names(x))
        p <- ncol(x)
    }
    nocols <- p == 0L
    if (is.logical(quote)) 
        quote <- NULL
    else if (is.numeric(quote)) {
        if (any(quote < 1L | quote > p)) 
            stop("invalid numbers in 'quote'")
    }
    else stop("invalid 'quote' specification")
    rn <- FALSE
    rnames <- NULL
    if (is.logical(row.names)) {
        if (row.names) {
            rnames <- as.character(d[[1L]])
            rn <- TRUE
        }
    }
    else {
        rnames <- as.character(row.names)
        rn <- TRUE
        if (length(rnames) != nrow(x)) 
            stop("invalid 'row.names' specification")
    }
    if (!is.null(quote) && rn) 
        quote <- c(0, quote)
    if (is.logical(col.names)) {
        if (!rn && is.na(col.names)) 
            stop("col.names = NA makes no sense when row.names = FALSE")
        col.names <- if (is.na(col.names) && rn) 
            c("", d[[2L]])
        else if (col.names) 
            d[[2L]]
        else NULL
    }
    else {
        col.names <- as.character(col.names)
        if (length(col.names) != p) 
            stop("invalid 'col.names' specification")
    }
    if (file == "") 
        file <- stdout()
    else if (is.character(file)) {
        file <- file(file, ifelse(append, "a", "w"))
        on.exit(close(file))
    }
    else if (!isOpen(file, "w")) {
        open(file, "w")
        on.exit(close(file))
    }
    if (!inherits(file, "connection")) 
        stop("'file' must be a character string or connection")
    qstring <- switch(qmethod, escape = "\\\\\"", double = "\"\"")
    if (!is.null(col.names)) {
        if (quoteC) 
            col.names <- paste("\"", gsub("\"", qstring, col.names), 
                "\"", sep = "")
        writeLines(paste(col.names, collapse = sep), file, sep = eol)
    }
    if (nrow(x) == 0L) 
        return(invisible())
    if (nocols && !rn) 
        return(cat(rep.int(eol, NROW(x)), file = file, sep = ""))
    if (is.matrix(x) && !is.atomic(x)) 
        mode(x) <- "character"
    if (is.data.frame(x)) {
        x[] <- lapply(x, function(z) {
            if (is.object(z) && !is.factor(z)) 
                as.character(z)
            else z
        })
    }
    .Internal(write.table(x, file, nrow(x), p, rnames, sep, eol, 
        na, dec, as.integer(quote), qmethod != "double"))
}


############## normalize by batch function
controlStatus <- function(types, genes, spottypecol="SpotType", regexpcol, verbose=TRUE)
{
#	Check input
	if (is(genes, "RGList") || is(genes, "MAList") || is(genes, "MArrayLM")) genes <- genes$genes
	cntypes <- colnames(types)
	cngenes <- colnames(genes)
	if(is.null(cntypes) || is.null(cngenes)) stop("types and genes must have column names")
	ntypes <- nrow(types)
	nspots <- nrow(genes)
	if(ntypes==0 || nspots==0) return(NULL)
#	Any undo conversion of types to factors
	for (j in cntypes) {
		x <- types[,j]
		if(is.factor(x) && is.character(levels(x))) types[,j] <- as.character(x)
	}
	if(is.numeric(spottypecol)) spottypecol <- cntypes[spottypecol[1]]
	if(is.null(spottypecol) || !is.character(spottypecol) || !is.element(spottypecol,cntypes))
		stop("spottypecol not valid column of types")

#	Find common columns between types and genes
	if(!missing(regexpcol) && is.numeric(regexpcol)) regexpcol <- cntypes[regexpcol]
	cntypes <- setdiff(cntypes,spottypecol)
	if(missing(regexpcol)) {
		incommon <- (cntypes %in% cngenes)
		if(!length(incommon)) stop("types and genes have no column names in common")
		regexpcol <- cntypes[incommon]
	} else {
		if(!all(is.element(regexpcol,cntypes) & is.element(regexpcol,cngenes)))
			stop("types and genes must both contain regexpcol colums")
	}
	if(verbose) cat("Matching patterns for:",regexpcol,"\n")

#	Simplified regular expressions
	#for (j in regexpcol) {
	#	types[,j] <- paste("^",gsub("\\*","\\.*",types[,j]),"$",sep="")
	#	genes[,j] <- as.character(genes[,j])
	#}

#	Set spot status
	spottype <- as.character(types[,spottypecol])
	if(default <- all(types[1,regexpcol]=="*")) {
		status <- rep(spottype[1],nspots)
		if(ntypes==1) return(status)
	} else
		status <- character(nspots)

nregexp <- length(regexpcol)
	for (i in (1+default):ntypes) {
		sel <- grep(types[i,regexpcol[1]],genes[,regexpcol[1]])

		if(nregexp>1) for (j in regexpcol[-1]) sel <- intersect(sel,grep(types[i,j],genes[,j]))
		status[sel] <- spottype[i]
		if(verbose) cat("Found",length(sel),spottype[i],"\n")
	}

#	Set attributes
	attr(status,"values") <- spottype
	cntypes <- setdiff(cntypes,regexpcol)
	npar <- length(cntypes)
	if(npar) {
		parnames <- sub("^Color$","col",cntypes)
		for (j in 1:npar) attr(status,parnames[j]) <- types[,cntypes[j]]
	}
	if(verbose) cat("Setting attributes: values",cntypes,"\n")
	status
}


normalizeWithinArraysBatch <- function(object,layout=object$printer,method="bPrinttip",weights=object$weights,span=0.3,iterations=4,controlspots=NULL,df=5,robust="M",bc.method="minimum",offset=0, batch=batch)
#	Within array normalization with batch mode
#
{
	if(!is(object,"MAList")) object <- MA.RG(object,bc.method=bc.method,offset=offset)
	choices <- c("none","median","loess","printtiploess","composite","control","robustspline", "batch", "bPrinttip")
	method <- match.arg(method,choices)
	if(method=="none") return(object)
	if(is.vector(object$M)) object$M <- as.matrix(object$M)
	if(is.vector(object$A)) object$A <- as.matrix(object$A)
	if(is.vector(weights)) weights <- as.matrix(weights)
	narrays <- ncol(object$M)
	if(method=="median") {
		if(is.null(weights))
			for (j in 1:narrays) object$M[,j] <- object$M[,j] - median(object$M[,j],na.rm=TRUE)
		else
			for (j in 1:narrays) object$M[,j] <- object$M[,j] - weighted.median(object$M[,j],weights[,j],na.rm=TRUE)
		return(object)
	}
#	All remaining methods use regression of M-values on A-values
	switch(method,
		batch ={
			for (j in 1:narrays) {
				y <- object$M[batch,j]
				x <- object$A[batch,j]
				w <- weights[batch,j]
				object$M[batch,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
				cbatch<-setdiff(1:nrow(object$M), batch)
				y <- object$M[cbatch,j]
				x <- object$A[cbatch,j]
				w <- weights[cbatch,j]
				object$M[cbatch,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
			}
		},
		bPrinttip ={
			if(is.null(layout)) stop("Layout argument not specified")
			ngr <- layout$ngrid.r
			ngc <- layout$ngrid.c
			nspots <- layout$nspot.r * layout$nspot.c
			nprobes <- ngr*ngc*nspots
			if(nprobes != NROW(object$M)) stop("printer layout information does not match M row dimension")
			if(nprobes != NROW(object$A)) stop("printer layout information does not match A row dimension")
			for (j in 1:narrays) {
				spots <- 1:nspots
				for (gridr in 1:ngr)
				for (gridc in 1:ngc) {
					spots1<-intersect(batch, spots)
					cbatch<-setdiff(1:nrow(object$M), batch)
					spots2<-intersect(cbatch, spots)
					y <- object$M[spots1,j]
					x <- object$A[spots1,j]
					w <- weights[spots1,j]
					object$M[spots1,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
					y <- object$M[spots2,j]
					x <- object$A[spots2,j]
					w <- weights[spots2,j]
					object$M[spots2,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
					spots <- spots + nspots
				}
			}

		},
		loess = {
			for (j in 1:narrays) {
				y <- object$M[,j]
				x <- object$A[,j]
				w <- weights[,j]
				object$M[,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
			}
		},
		printtiploess = {
			if(is.null(layout)) stop("Layout argument not specified")
			ngr <- layout$ngrid.r
			ngc <- layout$ngrid.c
			nspots <- layout$nspot.r * layout$nspot.c
			nprobes <- ngr*ngc*nspots
			if(nprobes != NROW(object$M)) stop("printer layout information does not match M row dimension")
			if(nprobes != NROW(object$A)) stop("printer layout information does not match A row dimension")
			for (j in 1:narrays) {
				spots <- 1:nspots
				for (gridr in 1:ngr)
				for (gridc in 1:ngc) {
					y <- object$M[spots,j]
					x <- object$A[spots,j]
					w <- weights[spots,j]
					object$M[spots,j] <- loessFit(y,x,w,span=span,iterations=iterations)$residuals
					spots <- spots + nspots
				}
			}
		},
		composite = {
			if(is.null(layout)) stop("Layout argument not specified")
			if(is.null(controlspots)) stop("controlspots argument not specified")
			ntips <- layout$ngrid.r * layout$ngrid.c
			nspots <- layout$nspot.r * layout$nspot.c
			for (j in 1:narrays) {
				y <- object$M[,j]
				x <- object$A[,j]
				w <- weights[,j]
				f <- is.finite(y) & is.finite(x) & is.finite(w)
				y[!f] <- NA
				fit <- loess(y~x,weights=w,span=span,subset=controlspots,na.action=na.exclude,degree=0,surface="direct",family="symmetric",trace.hat="approximate",iterations=iterations)
				alpha <- global <- y
				global[f] <- predict(fit,newdata=x[f])
				alpha[f] <- (rank(x[f])-1) / sum(f)
				spots <- 1:nspots
				for (tip in 1:ntips) {
					y <- object$M[spots,j]
					x <- object$A[spots,j]
					w <- weights[spots,j]
					local <- loessFit(y,x,w,span=span,iterations=iterations)$fitted
					object$M[spots,j] <- object$M[spots,j] - alpha[spots]*global[spots]-(1-alpha[spots])*local
					spots <- spots + nspots
				}
			}
		},
		control = {
			if(is.null(layout)) stop("Layout argument not specified")
			if(is.null(controlspots)) stop("controlspots argument not specified")
			ntips <- layout$ngrid.r * layout$ngrid.c
			nspots <- layout$nspot.r * layout$nspot.c
			for (j in 1:narrays) {
				y <- object$M[,j]
				x <- object$A[,j]
				f <- is.finite(y) & is.finite(x)
				if(!is.null(weights)) {
					w <- weights[,j]
					f <- f & is.finite(w)
				}
				y[!f] <- NA
				fit <- loess(y~x,weights=w,span=span,subset=controlspots,na.action=na.exclude,degree=1,surface="direct",family="symmetric",trace.hat="approximate",iterations=iterations)
				y[f] <- y[f]-predict(fit,newdata=x[f])
				object$M[,j] <- y
			}
		},
		robustspline = {
			if(is.null(layout)) stop("Layout argument not specified")
			for (j in 1:narrays)
				object$M[,j] <- normalizeRobustSpline(object$M[,j],object$A[,j],layout,df=df,method=robust)
		}
	)
	object
}
