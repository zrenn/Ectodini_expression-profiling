######## GenMask Functions
######## Heather Machado 20100812
#
#   These two functions, "groupsize" and "maskplot", use array comparative genomic 
#   hybridization (aCGH) data to inform gene expression studies by constructing a 
#   mask for features that have genomic bias. 
#   They determine the # of genes to mask based on the strength of the correlation 
#   of the between-species genomic hybridization ratio and expression 
#   hybridization ratio (Exp/Gen correlation), for a set of genes with species-
#   biased expression.
#
################################################################################

# groupsize
#
#Description:
#   Plots the correlation between genomic and expression between-species 
#   coefficients (Exp/Gen correlation) for an increasing groupsize (size of 
#   group of genes with species-biased expression).
#   The user determines the optimal groupsize- the set of most significantly
#   regulated genes that is > 50 genes and has the greatest significant Exp/Gen
#   correlation- 
#	This is the set-size that will be used in genomic mask contruction.
#   This was selected as "optimal" because gene sets too small 
#	have spruious correlation and gene sets to large can 
#	obscure the correlation.
#
#Usage:  
#   groupsize(x = 2000, stp = 2, ehyb, ghyb, main, pvalue = 0.05)
#
#Arguments:
#   ehyb: an object containing the expression data. Must have columns labelled:
#        "ID": the unique identifier for the gene. Is matched with ID's in ghyb
#        "ExpRatio": the coefficents from the test of between-species expression
#        "pvalue": the p-value for the test of between-species expression
#   ghyb: an object containing the genomic data. Must have columns labelled: 
#        "ID": the unique identifier for the gene. Is matched with ID's in ehyb
#        "GenRatio": the coefficents from the test of between-species genomic bias
#        "pvalue": the p-value for the test of between-species genomic bias
#   pvalue: a value specifying the pvalue threshold for considering the Exp/Gen
#        correlation significant
#   max.size: a value specifying the maximum group size to test
#   min.size: a value specifying the minimum group size to test
#   ...: arguments passed to plot function
#
#Details:
#   The default is to find the groupsize where p < 0.05 and the Exp/Gen correlation
#   is maximized. There is a minimum groupsize of 50 genes.
#
#Value:
#    Plots the changing Exp/Gen correlation with increasing groupsize. 
#    Returns a list with the value representing the optimal groupsize ("groupsize"),
#    the original "ehyb" and "ghyb" objects. 
#    This object can be fed directly into the function "maskplot".
#
#Examples:
#   expdata <- data(exp1) #expression array data
#   gendata <- data(gen1) #genomic array data
#   testgroupGS <- groupsize(ehyb=expdata, ghyb=gendata) # indicates size of testgroup
#   genomic.mask <- maskplot(testgroupGS) # list genes to mask

groupsize <- function(ehyb, ghyb, pvalue = 0.05, max.size = 2000, min.size = 50, ...) {
  if(max.size > length(ehyb$ID))
    stop("max.size must be less than or equal to length of dataset")
  if(max.size <= min.size)
    stop("max.size must be greater than ", min.size)
  if(pvalue <= 0 | pvalue >= 1)
    stop("specified p-value must be between 0 and 1")
  ehybi <- ehyb[, c(which(colnames(ehyb) == "ID"), 
    which(colnames(ehyb) == "ExpRatio"), which(colnames(ehyb) == "pvalue"))]
  if(ncol(ehybi) != 3)
    stop("expression hyb object must have columns 'ID', 'ExpRatio' and 'pvalue'")
  ehybii <- na.omit(ehybi) # omitting genes with NA values
  cat("expression data found for", nrow(ehybii), "genes \n")
  if(sum(duplicated(ehybii$ID)) > 0)
    stop(sum(duplicated(ehybii$ID)), " gene ID's not unique in expression dataset")
  ghybi <- ghyb[, c(which(colnames(ghyb) == "ID"), 
    which(colnames(ghyb) == "GenRatio"), which(colnames(ghyb) == "pvalue"))]
  if(ncol(ghybi) != 3)
    stop("genomic hyb object must have columns 'ID', 'GenRatio' and 'pvalue'")
  ghybii <- na.omit(ghybi) # omitting genes with NA values
  cat("genomic data found for", nrow(ghybii), "genes \n")
  if(sum(duplicated(ghybii$ID)) > 0)
  stop(sum(duplicated(ghybii$ID)), " gene ID's not unique in genomic dataset")
  stp <- 2
  xs <-  (max.size - (min.size - 1)) / stp  # the number of steps to plot
  mat <- matrix(nrow = xs, ncol = 5)  # matrix that the data will
  gh <- merge(ehybii, ghybii, by = "ID")
  cat("there are", nrow(gh), "genes with data in both the expression and genomic datasets \n")
  gh2 <- gh[order(gh$pvalue.x), ]    # order the expression data by pvalue
  for (i in 1:xs) {
       n <- stp*i + (min.size - 1)
       m1 <- gh2[(1:n), ]
       m2 <- gh2[ - (1:n), ]
       c1 <- cor.test(m1$ExpRatio, m1$GenRatio) 
       c2 <- cor.test(m2$ExpRatio, m2$GenRatio)
       mat[i, 1] <- n
       mat[i, 2] <- as.numeric(c1[3])    #pvalue
       mat[i, 3] <- as.numeric(c1[4])    #estimate
       mat[i, 4] <- as.numeric(c2[3])    #pvalue  ns
       mat[i, 5] <- as.numeric(c2[4])    #estimate  ns
       }
  mat2 <- mat[mat[, 2] < pvalue, ]
  mat3 <- mat2[mat2[, 3] > 0, ]
  if(nrow(mat3) == 0) 
    stop("There are no groups with a positive Exp/Gen correlation for the signficiance threshold and max groupsize specified")
  groupsize <- mat3[mat3[, 3] == max(mat3[, 3]), 1]
  par(oma=c(0, 0, 0, 2))
  plot(mat[, 1], mat[, 3], pch = 16, col = "red", ylim = c(-(max(abs(c(mat[, 3], 
       mat[, 5])))), max(abs(c(mat[, 3],mat[, 5])))), 
       xlab = "# sig genes included", ylab = "exp/gen correlation")
  points(mat[, 1], mat[, 5], pch = 16, col = "black", cex = .6) 
  par(new = T)  
  plot(mat[, 1], mat[, 2], pch = 17, col = "purple", yaxt = "n",  
       ylim = c(0, pvalue*2), xlab = "# sig genes included", ylab = "", ...) 
  axis(side = 4)
  mtext("p-value", side = 4, line = 2.5) 
  points(mat[, 1], mat[, 4], pch = 17, col = "green", cex = .6) 
  abline(h = pvalue, col = "blue") 
  legend(x = "topright", legend = c("R sig", "pvalue sig", "R ns", "pvalue ns"), 
         col = c("red", "purple", "black", "green"), pch = c(16, 17), bty = "n", 
         pt.cex = c(1, 1, .6, .6))
  text(x = groupsize, y = 0.05, labels = groupsize, cex = 2, font = 2)
  list1 <- list(groupsize, ehyb, ghyb)
  cat("\n groupsize \n", groupsize, "\n")
  names(list1) <-  c("groupsize", "ehyb", "ghyb")
  list1
}


# maskplot
#
#Description:
#   Plots the correlation of genomic and expression between-species 
#   coefficients (Exp/Gen correlation) of the group of genes with species-biased 
#   expression, with an increasing number of genomic-bias features removed 
#   (increasing mask size) always testing the same size test group (determined by groupsize function).
#   The user determines the number of genes to mask that results in a non-significant (p>0.05)
#   Exp/Gen correlation for the test group size.
#	 
#Usage:  
#   maskplot(GSobject = NULL, x = 2000, ehyb = GSobject$ehyb, 
#                     ghyb = GSobject$ghyb, main = NULL, pvalue = 0.1, 
#                     sig.size = GSobject$groupsize, ...)
#
#Arguments:
#   GSobject: a object created with "groupsize", containing the genomic and expression
#         hybridization ratios between-species and the groupsize of genes with 
#         species-biased expression for mask testing. If GS object is specified, 
#         "ehyb", "ghyb", and "sig.size" do not need to be specified
#   max.size: the maximum mask size to test
#   ehyb: an object containing the expression data. Must have columns labelled:
#        "ID": the unique identifier for the gene. Is matched with ID's in ghyb
#        "ExpRatio": the coefficents from the test of between-species expression
#        "pvalue": the p-value for the test of between-species expression
#   ghyb: an object containing the genomic data. Must have columns labelled: 
#        "ID": the unique identifier for the gene. Is matched with ID's in ehyb
#        "GenRatio": the coefficents from the test of between-species genomic bias
#        "pvalue": the p-value for the test of between-species genomic bias
#   main: a character string for the title of the plot
#   pvalue: a value specifying the pvalue threshold for considering the Exp/Gen
#        correlation no longer significant 
#   ...: arguments passed to plot function
#
#Details:
#   The default is to find the number of genes to mask that results in a non-significant
#   Exp/Gen correlation, with P > 0.1. Only genes with genomic and expression
#   ratios that are biased in the same direction are masked, avoiding false positives
#
#Value:
#    Plots the changing Exp/Gen correlation with increasing mask size.
#    Returns a dataframe of the genes to mask from the expression analysis and 
#    the expression and genomic hybridization data for those genes.
#
#Examples:
#   expdata <- data(exp1) #between-species expression data
#   gendata <- data(gen1) #between-species genomic data
#   testgroupGS <- groupsize(ehyb=expdata, ghyb=gendata) # indicates size of testgroup
#   genomic.mask <- maskplot(testgroupGS) # list genes to mask

maskplot <- function(GSobject = NULL, ehyb = GSobject$ehyb, 
                     ghyb = GSobject$ghyb, pvalue = 0.1, max.size = 1000, 
                     sig.size = GSobject$groupsize, ... ) {
  if(sig.size > length(ehyb$ID))
    stop("sig.size must be less than or equal to length of dataset")
  if(pvalue <= 0 | pvalue >= 1)
    stop("specified p-value must be between 0 and 1")
  ehybi <- ehyb[, c(which(colnames(ehyb) == "ID"), 
    which(colnames(ehyb) == "ExpRatio"), which(colnames(ehyb) == "pvalue"))]
  if(ncol(ehybi) != 3)
    stop("expression hyb object must have columns 'ID', 'ExpRatio' and 'pvalue'")
  ehybii <- na.omit(ehybi) # omitting genes with NA values
  cat("expression data found for ", nrow(ehybii), " genes \n")
  if(sum(duplicated(ehybii$ID)) > 0)
    stop(sum(duplicated(ehybii$ID)), " gene ID's not unique in expression dataset")
  ghybi <- ghyb[, c(which(colnames(ghyb) == "ID"), 
    which(colnames(ghyb) == "GenRatio"), which(colnames(ghyb) == "pvalue"))]
  if(ncol(ghybi) != 3)
    stop("genomic hyb object must have columns 'ID', 'GenRatio' and 'pvalue'")
  ghybii <- na.omit(ghybi) # omitting genes with NA values
  cat("genomic data found for ", nrow(ghybii), " genes \n")
  if(sum(duplicated(ghybii$ID)) > 0)
    stop(sum(duplicated(ghybii$ID)), " gene ID's not unique in genomic dataset")
  stp <- 2
  ghybii$Ratioab <- abs(ghybii$GenRatio) # to measure magnitude of genomic hyb bias
  m1 <- merge(ehybii, ghybii, by = "ID")
  cat("there are", nrow(m1), "genes with data in both the expression and genomic datasets \n")
  # the following gives a features with gen and exp ratios with opposite bias a "0" gen ratio value
  # this avoids "false postive" masking
  m1$Ratioab <- ifelse((m1$ExpRatio > 0 &  m1$GenRatio < 0) | (m1$ExpRatio < 0 
                       &  m1$GenRatio > 0), 0, m1$Ratioab) 
  m1.o <- m1[order(m1$Ratioab, decreasing = TRUE), ] # in decreasing order of gen ratio magnitude
  xs <- max.size / stp # the number of steps to plot
  mat <- matrix(nrow = xs, ncol = 5) # will put the correlation results into this new matrix
  for (i in 0:xs){
       n <- stp * i  # number of genes masked (from entire dataset- not known how many are masked from sig group)
       m1.del <- m1.o[ - (1:n), ]
       m2 <- m1.del[order(m1.del$pvalue.x), ]  # order the expression data by pvalue
       m.s <- m2[(1:sig.size), ]
       m.ns <- m2[ - (1:sig.size), ]
       c1 <- cor.test(m.s$ExpRatio, m.s$GenRatio)  
       c2 <- cor.test(m.ns$ExpRatio, m.ns$GenRatio)
       mat[i, 1] <- n
       mat[i, 2] <- as.numeric(c1[3])    #pvalue
       mat[i, 3] <- as.numeric(c1[4])    #estimate
       mat[i, 4] <- as.numeric(c2[3])    #pvalue  ns
       mat[i, 5] <- as.numeric(c2[4])    #estimate  ns
       }
  mat2 <- mat[mat[, 2] > pvalue, ]          
  if(nrow(mat2) == 0)      
  warning("no mask could be generated for the specified parameters")
  size <- mat2[1, 1]     
  mat3 <- m1.o[1:size, ]
  par(oma = c(0, 0, 0, 2))
  plot(mat[, 1], mat[, 3], pch = 16, col = "red", ylim =
       c( - (max(abs(c(mat[, 3], mat[, 5])))), max(abs(c(mat[, 3], mat[, 5])))),
       xlab = "# genes masked", ylab = "exp/gen correlation", ...)
  points(mat[, 1], mat[, 5], pch = 16, col = "black", cex = .7) 
  par(new = T)  
  plot(mat[, 1], mat[, 2], pch = 17, col = "purple", yaxt = "n",
       ylim = c(0, pvalue*2), xlab = "", ylab = "", cex = .9) 
  axis(side = 4)
  mtext("p-value", side = 4, line = 2.5) 
  points(mat[, 1], mat[, 4], pch = 17, col = "green", cex = .6) 
  abline(h = pvalue, col = "blue") 
  legend(x = "topright", legend = c("sig correlation", "sig p-value", 
         "ns correlation", "ns p-value"), col = c("red", "purple", "black", 
         "green"), pch = c(16, 17), bty = "n", pt.cex = c(1, .9, .7, .6))
  text(x = size, y = 0.05, labels = size, cex = 2, font = 2)
  cat("\n masksize \n", size, "\n")
  mat3
}
