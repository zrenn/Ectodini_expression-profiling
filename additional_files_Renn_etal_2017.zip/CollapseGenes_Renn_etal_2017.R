############# COLLAPSE GENES FUNCTION
########## Sara Natale 20100727
#
#Description:
#	finds repeated TC IDs from a gal file
#	"collapses" results into a new MA object called AveMA
#	puts information of features that have been used in the 
# 	averaging into new AveMA$genes (Names, Spots, GBs), 
#	separated by a |. This function REQUIRES that gal file 

#	has column called "DFCI_TC_2009" which contains TC ID, 
#	"NO_2009_TC", or "none". Should be used in conjunction 
#	with the function CompCalcWeights (/afs/reed.edu/dpartments
#	/Biology/Renn/jones._renn/scripts/20100715_CompCalcWeights).
#
#Usage:
#	AveMA <- CollapseGenes(RG, MA)
#
#Arguments:
#	RG: RGList object created by standard data read-in, with on 
#	which data quality filters have been performed (NAs in RG$R 
#	and RG$G) 
#	MA: MArray object created from performing 
#	normalizeWithinArrays (and/or normalizeBetweenArrays and/or 
#	batch normalization) on above RG object with desired 
#	normalization method.


###Collapse Gene list
CollapseGenes <- function(RG, MA) 
	{
	#Arguments:
#	RG: RGList object created by standard data read-in, with on 
#	which data quality filters have been performed (NAs in RG$R 
#	and RG$G) 
#	MA: MArray object created from performing 
#	normalizeWithinArrays (and/or normalizeBetweenArrays and/or 
#	batch normalization) on above RG object with desired 
#	normalization method.	
	#find indices of no TC's:
	no.TC.N <- sort(which(("NO_2009_TC" == RG$genes$DFCI_TC_2009)|("none"==RG$genes$DFCI_TC_2009)))
	#names of no TC genes
	no.TC <- RG$genes$Name[no.TC.N]
	#find TC names of all repeated genes:
	reps <- RG$genes$DFCI_TC_2009[-no.TC.N]
	#make a sorted listed of all unique repeated gene names
	uniq.reps<-sort(unique(reps))
	#find first occurence of repeated genes (row#)
	reps.N <- match(uniq.reps, RG$genes$DFCI_TC_2009)
	#put lists of indices together
	genes.N <- c(no.TC.N, reps.N)
	#put lists of names together
	genes <- c(no.TC, uniq.reps)
	#create a new MA object
	AveMA<-MA
	#make AveMA$M the right dimensions
	AveMA$M<-MA$M[genes.N,]
	#make AveMA$A the right dimensions
	AveMA$A<-MA$A[genes.N,]
	#import the unique genes right into AveMA$genes
	AveMA$genes<- RG$genes[genes.N, ]
	#for TC genes, replace the hhID code with the TC
	AveMA$genes$ID[(length(no.TC.N) + 1):length(AveMA$genes$ID)]<-uniq.reps
		
	
	#first go through the singletons
	for(i in 1:length(no.TC))
		{
		AveMA$M[i, ] <- MA$M[no.TC.N[i], ]
		AveMA$A[i, ] <- MA$A[no.TC.N[i], ]	
		}
	
	for(i in (length(no.TC.N)+1):(length(genes.N)))
		{
		#list all gene duplicates	
		n<-which(genes[i]==RG$genes$DFCI_TC_2009)
		#replace the name column of AveMA$genes with list of analyzed hhIDs
		ids <- NULL
		spots <- NULL
		gbs <- NULL
			for(j in n)
				{
				new.id <- NULL	
				new.spot <- NULL
				new.gb <- NULL
				if(sum(!is.na(MA$M[j, ]))>0){
					new.id <- RG$genes$Name[j]
					new.spot <- RG$genes$Spot[j]
					new.gb <- RG$genes$GB_accession[j]
					}
					ids <- c(ids, new.id)	
					spots <- c(spots, new.spot)
					gbs <- c(gbs, new.gb)
									}
		AveMA$genes$Name[i] <- paste(ids, collapse = "|")
		AveMA$genes$Spot[i] <- paste(spots, collapse = "|")
		AveMA$genes$GB_accession[i] <- paste(gbs, collapse = "|")
		AveMA$M[i, ]<-colMeans(matrix(MA$M[n,], nrow = length(n)), na.rm=TRUE, dims=1)#average them in $M
		AveMA$A[i, ]<-colMeans(matrix(MA$A[n,], nrow = length(n)), na.rm=TRUE, dims=1)#average them in $A
		}
	return(AveMA)
}
